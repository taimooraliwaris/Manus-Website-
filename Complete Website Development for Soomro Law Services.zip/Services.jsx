import React from 'react'
import { motion } from 'framer-motion'
import { Scale, ArrowRight, CheckCircle } from 'lucide-react'
import { Link } from 'react-router-dom'

const Services = () => {
  const servicesData = [
    {
      title: 'Civil, Criminal, Labour & Corporate Laws',
      description: 'Comprehensive legal representation across civil disputes, criminal defense, labour law matters, and corporate legal requirements. Our experienced team handles complex litigation with precision and dedication.',
      icon: '⚖️',
      keyAreas: ['Civil Litigation', 'Criminal Defense', 'Labour Law', 'Corporate Compliance'],
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Company Formation & Business Registration',
      description: 'Complete business setup services including company formation, dissolution, AOP registration, and individual & sole proprietor registration with full legal compliance.',
      icon: '🏢',
      keyAreas: ['Company Formation', 'Business Dissolution', 'AOP Registration', 'Sole Proprietor Setup'],
      color: 'from-green-500 to-green-600'
    },
    {
      title: 'Trade Mark Registration & IP Protection',
      description: 'Protect your intellectual property with our comprehensive trademark registration services and ongoing IP protection strategies.',
      icon: '🛡️',
      keyAreas: ['Trademark Registration', 'IP Protection', 'Brand Registration', 'Copyright Services'],
      color: 'from-purple-500 to-purple-600'
    },
    {
      title: 'Tax Services & Compliance',
      description: 'Complete tax services including FBR audits, notification compliances, sales tax returns, income tax returns for companies, AOPs, and individuals.',
      icon: '📊',
      keyAreas: ['FBR Audits', 'Sales Tax Returns', 'Income Tax Returns', 'Tax Compliance'],
      color: 'from-red-500 to-red-600'
    },
    {
      title: 'Financial Statements & Audit Services',
      description: 'Professional financial statement preparation, internal and external audits, and comprehensive accounting services for businesses of all sizes.',
      icon: '📈',
      keyAreas: ['Financial Statements', 'Internal Audits', 'External Audits', 'Accounting Services'],
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      title: 'Withholding & Refund Services',
      description: 'Expert handling of withholding statements (quarterly/annually), sales tax refunds, and income tax refunds with efficient processing.',
      icon: '💰',
      keyAreas: ['Withholding Statements', 'Tax Refunds', 'Quarterly Reports', 'Annual Filings'],
      color: 'from-indigo-500 to-indigo-600'
    }
  ]

  const processSteps = [
    {
      step: '1',
      title: 'Initial Consultation',
      description: 'We discuss your case and provide initial legal assessment with transparent communication.'
    },
    {
      step: '2',
      title: 'Case Analysis',
      description: 'Thorough review of your case and development of comprehensive legal strategy.'
    },
    {
      step: '3',
      title: 'Legal Action',
      description: 'Implementation of legal strategy with expert representation and ongoing support.'
    },
    {
      step: '4',
      title: 'Resolution',
      description: 'Achieving the best possible outcome for your case with complete satisfaction.'
    }
  ]

  return (
    <div className="pt-20">
      {/* Header Section */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-black py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto max-w-2xl text-center"
          >
            <div className="flex justify-center mb-8">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-4 rounded-2xl animate-glow">
                <Scale className="h-12 w-12 text-black" />
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
              Our Legal Services
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              We provide comprehensive legal services across multiple practice areas, delivering 
              expert counsel and representation tailored to your specific needs with integrity and excellence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {servicesData.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-8 group hover:scale-105 transition-all duration-300"
              >
                <div className="flex items-start space-x-4 mb-6">
                  <div className={`bg-gradient-to-r ${service.color} p-3 rounded-xl group-hover:animate-glow`}>
                    <span className="text-2xl">{service.icon}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed">{service.description}</p>
                
                <div className="mb-6">
                  <h4 className="text-white font-medium mb-3">Key Areas:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {service.keyAreas.map((area, areaIndex) => (
                      <div key={areaIndex} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-yellow-400 flex-shrink-0" />
                        <span className="text-gray-300 text-sm">{area}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Link
                  to="/consultation"
                  className="inline-flex items-center text-yellow-400 hover:text-yellow-300 font-medium text-sm transition-colors group-hover:translate-x-1 duration-300"
                >
                  Get Consultation
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Our Legal Process
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              We follow a structured approach to ensure the best outcomes for our clients
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className="relative mb-6">
                  <div className="mx-auto w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-black font-bold text-xl group-hover:animate-glow transition-all duration-300">
                    {step.step}
                  </div>
                  {index < processSteps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-yellow-400/50 to-transparent"></div>
                  )}
                </div>
                <h3 className="text-lg font-semibold text-white mb-3">{step.title}</h3>
                <p className="text-gray-300 text-sm leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="mx-auto max-w-4xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-card p-12"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Need legal assistance?
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Let's discuss your case.
            </p>
            <Link
              to="/consultation"
              className="btn-gold px-8 py-4 rounded-lg text-lg font-semibold inline-flex items-center"
            >
              Book Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default Services

