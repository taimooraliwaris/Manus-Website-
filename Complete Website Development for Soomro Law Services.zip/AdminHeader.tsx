'use client'

import { signOut } from 'next-auth/react'
import { Scale, LogOut, User } from 'lucide-react'

export default function AdminHeader() {
  return (
    <header className="bg-dark-900 border-b border-gold-500/20 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-r from-gold-400 to-gold-600 p-2 rounded-lg">
            <Scale className="h-6 w-6 text-dark-900" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Soomro Law Services</h1>
            <p className="text-sm text-gray-400">Admin Dashboard</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-gray-300">
            <User className="h-5 w-5" />
            <span>Admin</span>
          </div>
          <button
            onClick={() => signOut({ callbackUrl: '/admin/login' })}
            className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </header>
  )
}

