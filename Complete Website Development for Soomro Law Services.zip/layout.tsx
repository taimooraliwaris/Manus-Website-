import type { Metadata } from "next";
import "./globals.css";
import Providers from "@/components/Providers";

export const metadata: Metadata = {
  title: "Soomro Law Services - Professional Legal Services",
  description: "Expert legal counsel with a modern approach. We provide comprehensive legal solutions tailored to your specific needs with integrity and excellence.",
  keywords: "law firm, legal services, Pakistan, civil litigation, criminal defense, corporate law, family law, Soomro Law Services",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}