import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Calendar, Clock, MapPin, Phone, Mail, CheckCircle } from 'lucide-react'

const Consultation = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    serviceType: '',
    preferredDate: '',
    selectedTime: '',
    description: ''
  })
  
  const [availableSlots, setAvailableSlots] = useState([])
  const [showTimeSlots, setShowTimeSlots] = useState(false)

  const services = [
    'Civil, Criminal, Labour & Corporate Laws',
    'Company Formation/Dissolution',
    'Trade Mark Registration',
    'FBR Audits/Notification Compliances',
    'Filing Sales Tax Returns',
    'Income Tax Returns',
    'Financial Statements',
    'Internal & External Audits'
  ]

  const timeSlots = [
    { time: '09:00 AM', available: true },
    { time: '10:00 AM', available: true },
    { time: '11:00 AM', available: false },
    { time: '12:00 PM', available: true },
    { time: '02:00 PM', available: true },
    { time: '03:00 PM', available: true },
    { time: '04:00 PM', available: true },
    { time: '05:00 PM', available: true },
  ]

  const handleDateChange = (e) => {
    const date = e.target.value
    setFormData({ ...formData, preferredDate: date })
    if (date) {
      setAvailableSlots(timeSlots)
      setShowTimeSlots(true)
    } else {
      setShowTimeSlots(false)
    }
  }

  const handleTimeSelect = (time) => {
    setFormData({ ...formData, selectedTime: time })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log('Consultation booked:', formData)
    alert('Consultation booked successfully! We will contact you soon.')
  }

  return (
    <div className="pt-20">
      {/* Header Section */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-black py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto max-w-2xl text-center"
          >
            <div className="flex justify-center mb-8">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-4 rounded-2xl animate-glow">
                <Calendar className="h-12 w-12 text-black" />
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
              Book a Consultation
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Schedule a consultation with our experienced legal team. We're here to help you 
              navigate your legal challenges with expert guidance and personalized solutions.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Booking Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Personal Information</h2>
              <p className="text-gray-300 mb-8">Please provide your contact details so we can reach you.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Full Name *</label>
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                      placeholder="Enter your full name"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Email Address *</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-white mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                    placeholder="+92 XXX XXXXXXX"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-white mb-2">Service Type *</label>
                  <select
                    value={formData.serviceType}
                    onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                    className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                    required
                  >
                    <option value="">Select a service</option>
                    {services.map((service, index) => (
                      <option key={index} value={service}>{service}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-white mb-2">Preferred Date *</label>
                  <input
                    type="date"
                    value={formData.preferredDate}
                    onChange={handleDateChange}
                    className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                    min={new Date().toISOString().split('T')[0]}
                    required
                  />
                </div>

                {/* Time Slots */}
                {showTimeSlots && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    transition={{ duration: 0.5 }}
                  >
                    <label className="block text-sm font-medium text-white mb-4">Available Time Slots *</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {availableSlots.map((slot, index) => (
                        <button
                          key={index}
                          type="button"
                          onClick={() => slot.available && handleTimeSelect(slot.time)}
                          disabled={!slot.available}
                          className={`time-slot p-3 rounded-lg text-sm font-medium transition-all duration-300 ${
                            formData.selectedTime === slot.time
                              ? 'selected'
                              : slot.available
                              ? 'hover:scale-105'
                              : 'booked'
                          }`}
                        >
                          {slot.time}
                          {!slot.available && <span className="block text-xs">Booked</span>}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                <div>
                  <label className="block text-sm font-medium text-white mb-2">Brief Description of Your Legal Matter</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                    className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all resize-none"
                    placeholder="Please provide a brief description of your legal matter..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full btn-gold py-4 rounded-lg text-lg font-semibold"
                >
                  Book Consultation
                </button>
              </form>
            </motion.div>

            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-8"
            >
              <div className="glass-card p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Contact Information</h2>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                      <MapPin className="h-6 w-6 text-black" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Office Address</h3>
                      <p className="text-gray-300">Soomro Law Services</p>
                      <p className="text-gray-300">Fateh Garh, LHR</p>
                      <p className="text-gray-300">Pakistan</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                      <Phone className="h-6 w-6 text-black" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Phone Numbers</h3>
                      <div className="space-y-1 text-gray-300">
                        <p>+92 314 4622396</p>
                        <p>+92 305 4622396</p>
                        <p>+92 313 3448921</p>
                        <p>+92 309 5407616</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                      <Mail className="h-6 w-6 text-black" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Email</h3>
                      <p className="text-gray-300">soomrolawservices@gmail.com</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                      <Clock className="h-6 w-6 text-black" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">Office Hours</h3>
                      <div className="space-y-1 text-gray-300">
                        <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                        <p>Saturday: 10:00 AM - 2:00 PM</p>
                        <p>Sunday: Closed</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* What to Expect */}
              <div className="glass-card p-8">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-2 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-black" />
                  </div>
                  <h3 className="text-xl font-semibold text-white">What to Expect</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Initial consultation typically lasts 30-60 minutes</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Bring any relevant documents related to your case</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">We'll discuss your legal options and potential strategies</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-300">Transparent discussion of fees and timeline</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Consultation

