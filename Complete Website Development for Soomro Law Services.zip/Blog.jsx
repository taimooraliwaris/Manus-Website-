import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { BookOpen, Calendar, User, Tag, Search, ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [searchTerm, setSearchTerm] = useState('')

  const categories = ['All', 'Civil Law', 'Criminal Law', 'Corporate Law', 'Tax Law', 'Legal Updates']

  const blogPosts = [
    {
      id: 1,
      title: 'Understanding Civil Litigation Process in Pakistan',
      excerpt: 'A comprehensive guide to civil litigation procedures, timelines, and what to expect when pursuing a civil case in Pakistani courts.',
      category: 'Civil Law',
      author: 'Ali Soomro',
      date: '2024-12-15',
      readTime: '8 min read',
      image: '⚖️'
    },
    {
      id: 2,
      title: 'Corporate Compliance: Essential Requirements for Pakistani Businesses',
      excerpt: 'Navigate the complex landscape of corporate compliance in Pakistan with our detailed overview of legal requirements and best practices.',
      category: 'Corporate Law',
      author: 'Sadam Wako',
      date: '2024-12-10',
      readTime: '12 min read',
      image: '🏢'
    },
    {
      id: 3,
      title: 'Tax Law Updates: Recent Changes in FBR Regulations',
      excerpt: 'Stay updated with the latest changes in Federal Board of Revenue regulations and how they impact your tax obligations.',
      category: 'Tax Law',
      author: 'Farooq Haider Soomro',
      date: '2024-12-05',
      readTime: '6 min read',
      image: '📊'
    },
    {
      id: 4,
      title: 'Criminal Defense Strategies: Protecting Your Rights',
      excerpt: 'Learn about effective criminal defense strategies and understand your rights when facing criminal charges in Pakistan.',
      category: 'Criminal Law',
      author: 'Sadam Wako',
      date: '2024-11-28',
      readTime: '10 min read',
      image: '🛡️'
    },
    {
      id: 5,
      title: 'Trademark Registration: Protecting Your Brand in Pakistan',
      excerpt: 'A step-by-step guide to trademark registration process, requirements, and the importance of protecting your intellectual property.',
      category: 'Corporate Law',
      author: 'Ali Soomro',
      date: '2024-11-20',
      readTime: '7 min read',
      image: '🔒'
    },
    {
      id: 6,
      title: 'Recent Supreme Court Judgments: Impact on Business Law',
      excerpt: 'Analysis of recent Supreme Court decisions and their implications for business operations and corporate governance.',
      category: 'Legal Updates',
      author: 'Ali Soomro',
      date: '2024-11-15',
      readTime: '15 min read',
      image: '📚'
    }
  ]

  const filteredPosts = blogPosts.filter(post => {
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="pt-20">
      {/* Header Section */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-black py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto max-w-2xl text-center"
          >
            <div className="flex justify-center mb-8">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-4 rounded-2xl animate-glow">
                <BookOpen className="h-12 w-12 text-black" />
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
              Legal Insights & Updates
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Stay informed with the latest legal developments, expert insights, and practical 
              guidance from our experienced legal team.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-12 bg-black/30">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-black'
                      : 'bg-black/50 text-gray-300 hover:text-white hover:bg-white/10 border border-yellow-500/30'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {filteredPosts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <p className="text-gray-300 text-lg">No articles found matching your criteria.</p>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post, index) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="glass-card group hover:scale-105 transition-all duration-300 overflow-hidden"
                >
                  {/* Article Image/Icon */}
                  <div className="h-48 bg-gradient-to-br from-yellow-500/20 to-yellow-600/20 flex items-center justify-center group-hover:from-yellow-500/30 group-hover:to-yellow-600/30 transition-all duration-300">
                    <span className="text-6xl group-hover:animate-float">{post.image}</span>
                  </div>

                  <div className="p-6">
                    {/* Category Tag */}
                    <div className="flex items-center space-x-2 mb-4">
                      <Tag className="h-4 w-4 text-yellow-400" />
                      <span className="text-yellow-400 text-sm font-medium">{post.category}</span>
                    </div>

                    {/* Title */}
                    <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-yellow-400 transition-colors">
                      {post.title}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-gray-300 text-sm leading-relaxed mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>

                    {/* Meta Information */}
                    <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(post.date).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-gray-400 text-sm">{post.readTime}</span>
                      <button className="inline-flex items-center text-yellow-400 hover:text-yellow-300 font-medium text-sm transition-colors group-hover:translate-x-1 duration-300">
                        Read More
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-4xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-card p-8 text-center"
          >
            <h2 className="text-3xl font-bold text-white mb-4">
              Stay Updated with Legal Insights
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Subscribe to our newsletter for the latest legal updates and expert insights.
            </p>
            
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                required
              />
              <button
                type="submit"
                className="btn-gold px-6 py-3 rounded-lg font-semibold whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="mx-auto max-w-4xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Need Legal Advice?
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Our experienced legal team is here to help you navigate your legal challenges.
            </p>
            <Link
              to="/consultation"
              className="btn-gold px-8 py-4 rounded-lg text-lg font-semibold inline-flex items-center"
            >
              Schedule Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default Blog

