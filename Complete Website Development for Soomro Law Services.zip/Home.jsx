import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Users, Award, Clock, Star, ChevronLeft, ChevronRight } from 'lucide-react'
import { Link } from 'react-router-dom'

const Home = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    rating: 5,
    comment: ''
  })

  const stats = [
    { number: '1000+', label: 'Clients Served', icon: Users, color: 'from-blue-500 to-blue-600' },
    { number: '98%', label: 'Cases Won', icon: Award, color: 'from-yellow-500 to-yellow-600' },
    { number: '15+', label: 'Years Experience', icon: Clock, color: 'from-green-500 to-green-600' },
    { number: '4.9', label: 'Client Rating', icon: Star, color: 'from-purple-500 to-purple-600' },
  ]

  const features = [
    {
      title: 'Expert Legal Team',
      description: 'Our experienced lawyers provide comprehensive legal solutions across various practice areas with proven expertise.',
      icon: '⚖️'
    },
    {
      title: 'Client-Focused Approach',
      description: 'We prioritize our clients\' needs and work tirelessly to achieve the best possible outcomes with personalized attention.',
      icon: '🎯'
    },
    {
      title: 'Modern Technology',
      description: 'We leverage cutting-edge technology to streamline legal processes and improve efficiency for better client service.',
      icon: '💻'
    },
    {
      title: 'Transparent Communication',
      description: 'We maintain clear and open communication throughout the entire legal process, keeping you informed at every step.',
      icon: '📞'
    }
  ]

  const testimonials = [
    {
      name: 'Ahmed Hassan',
      initials: 'AH',
      role: 'Satisfied Client',
      comment: 'Excellent service and professional handling of my corporate law case. The team was incredibly knowledgeable and supportive throughout the entire process.',
      rating: 5
    },
    {
      name: 'Fatima Khan',
      initials: 'FK',
      role: 'Satisfied Client',
      comment: 'The team was very supportive during my family law matter. Their expertise and compassionate approach made a difficult situation much easier to handle.',
      rating: 5
    },
    {
      name: 'Muhammad Ali',
      initials: 'MA',
      role: 'Satisfied Client',
      comment: 'Professional, efficient, and trustworthy. Great experience with Soomro Law Services. I would highly recommend them to anyone needing legal assistance.',
      rating: 5
    }
  ]

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Handle form submission
    console.log('Review submitted:', formData)
    alert('Thank you for your review!')
    setFormData({ name: '', email: '', rating: 5, comment: '' })
  }

  useEffect(() => {
    const interval = setInterval(nextTestimonial, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black"></div>
        <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="animate-float">
              <div className="mx-auto w-32 h-32 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mb-8 animate-glow">
                <span className="text-6xl">⚖️</span>
              </div>
            </div>
            
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl">
              Professional Legal Services
              <span className="block gradient-text">You Can Trust</span>
            </h1>
            
            <p className="mx-auto max-w-2xl text-xl leading-8 text-gray-300">
              <span className="gradient-text font-semibold">Just Relax! You are in Safe Hands.</span> Expert legal counsel with a modern approach. 
              We provide comprehensive legal solutions tailored to your specific needs with integrity and excellence.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link
                to="/consultation"
                className="btn-gold px-8 py-4 rounded-lg text-lg font-semibold inline-flex items-center"
              >
                Book Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/services"
                className="px-8 py-4 rounded-lg text-lg font-semibold text-white border-2 border-yellow-500/50 hover:border-yellow-500 hover:bg-yellow-500/10 transition-all duration-300 inline-flex items-center"
              >
                Explore Our Services
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Trusted by Clients Across Pakistan
            </h2>
            <p className="text-gray-300 text-lg">Our track record speaks for itself</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-8 text-center group hover:scale-105 transition-all duration-300"
              >
                <div className={`mx-auto w-16 h-16 bg-gradient-to-r ${stat.color} rounded-full flex items-center justify-center mb-6 group-hover:animate-glow`}>
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="stat-number mb-2">{stat.number}</div>
                <p className="text-gray-300 font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Why Choose Soomro Law Services?
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              We combine legal expertise with modern technology to deliver exceptional results
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-8 group hover:scale-105 transition-all duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="text-4xl mb-4 group-hover:animate-float">{feature.icon}</div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                    <p className="text-gray-300 leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              What Our Clients Say
            </h2>
            <p className="text-gray-300 text-lg">Don't just take our word for it</p>
          </motion.div>

          <div className="relative max-w-4xl mx-auto">
            <div className="glass-card p-8 text-center">
              <div className="flex justify-center mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-6 w-6 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <blockquote className="text-xl text-gray-300 mb-8 leading-relaxed">
                "{testimonials[currentTestimonial].comment}"
              </blockquote>
              
              <div className="flex items-center justify-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
                  <span className="text-black font-bold">{testimonials[currentTestimonial].initials}</span>
                </div>
                <div>
                  <p className="font-semibold text-white">{testimonials[currentTestimonial].name}</p>
                  <p className="text-gray-400 text-sm">{testimonials[currentTestimonial].role}</p>
                </div>
              </div>
            </div>

            <button
              onClick={prevTestimonial}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-yellow-500/20 hover:bg-yellow-500/40 text-white p-2 rounded-full transition-all duration-300"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            
            <button
              onClick={nextTestimonial}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-yellow-500/20 hover:bg-yellow-500/40 text-white p-2 rounded-full transition-all duration-300"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        </div>
      </section>

      {/* Review Form Section */}
      <section className="py-24">
        <div className="mx-auto max-w-4xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Share Your Experience
            </h2>
            <p className="text-gray-300 text-lg">
              We value your feedback and would love to hear about your experience
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="glass-card p-8"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                    placeholder="Your full name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                    placeholder="your.email@example.com"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">Rating</label>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setFormData({ ...formData, rating: star })}
                      className="focus:outline-none"
                    >
                      <Star
                        className={`h-8 w-8 ${
                          star <= formData.rating ? 'text-yellow-400 fill-current' : 'text-gray-400'
                        } hover:text-yellow-400 transition-colors`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">Your Review</label>
                <textarea
                  value={formData.comment}
                  onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                  rows={4}
                  className="w-full px-4 py-3 bg-black/50 border border-yellow-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all resize-none"
                  placeholder="Share your experience with our legal services..."
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full btn-gold py-4 rounded-lg text-lg font-semibold"
              >
                Submit Review
              </button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-yellow-500/10 to-yellow-600/10">
        <div className="mx-auto max-w-4xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Ready to get started?
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Book your consultation today.
            </p>
            <Link
              to="/consultation"
              className="btn-gold px-8 py-4 rounded-lg text-lg font-semibold inline-flex items-center"
            >
              Book Consultation Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default Home

