const API_BASE_URL = 'https://3dhkilcqmv83.manus.space/api'

export const api = {
  async get(endpoint) {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`)
      const data = await response.json()
      return data
    } catch (error) {
      console.error('API GET Error:', error)
      throw new Error('Network error. Please check your connection.')
    }
  },

  async post(endpoint, data) {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      })
      const result = await response.json()
      return result
    } catch (error) {
      console.error('API POST Error:', error)
      throw new Error('Network error. Please check your connection.')
    }
  }
}

export const formatDate = (dateString) => {
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
}

export const formatPhone = (phone) => {
  // Format Pakistani phone numbers
  if (phone.startsWith('+92')) {
    return phone.replace('+92', '+92 ').replace(/(\d{3})(\d{7})/, '$1 $2')
  }
  if (phone.startsWith('0')) {
    return phone.replace(/(\d{4})(\d{7})/, '$1 $2')
  }
  return phone
}

export const validateEmail = (email) => {
  const pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
  return pattern.test(email)
}

export const validatePhone = (phone) => {
  // Pakistani phone number validation
  const pattern = /^\+92[0-9]{10}$|^0[0-9]{10}$/
  return pattern.test(phone)
}

