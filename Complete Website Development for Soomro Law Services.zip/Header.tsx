'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Scale, Menu, X } from 'lucide-react'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Services', href: '/services' },
    { name: 'Team', href: '/team' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/consultation' },
  ]

  return (
    <header className="bg-dark-950/95 backdrop-blur-sm border-b border-gold-500/20 sticky top-0 z-50">
      <nav className="mx-auto max-w-7xl px-6 lg:px-8" aria-label="Top">
        <div className="flex w-full items-center justify-between py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-gold-400 to-gold-600 p-2 rounded-lg">
                <Scale className="h-8 w-8 text-dark-900" />
              </div>
              <div>
                <span className="text-xl font-bold text-white">Soomro Law Services</span>
                <p className="text-xs text-gold-400">Just Relax! You are in Safe Hands</p>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex lg:items-center lg:space-x-8">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="text-gray-300 hover:text-gold-400 px-3 py-2 text-sm font-medium transition-colors duration-200"
              >
                {item.name}
              </Link>
            ))}
            <Link
              href="/consultation"
              className="bg-gradient-to-r from-gold-500 to-gold-600 text-dark-900 px-6 py-2 rounded-lg font-semibold hover:from-gold-400 hover:to-gold-500 transition-all duration-200 transform hover:scale-105"
            >
              Book Consultation
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              type="button"
              className="text-gray-300 hover:text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden">
            <div className="space-y-1 pb-4">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="block text-gray-300 hover:text-gold-400 px-3 py-2 text-base font-medium transition-colors duration-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <Link
                href="/consultation"
                className="block bg-gradient-to-r from-gold-500 to-gold-600 text-dark-900 px-6 py-2 rounded-lg font-semibold hover:from-gold-400 hover:to-gold-500 transition-all duration-200 mt-4 text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                Book Consultation
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}

