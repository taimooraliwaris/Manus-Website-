import React from 'react'
import { motion } from 'framer-motion'
import { Scale, Target, Eye, Heart, Award, Users, Clock, CheckCircle } from 'lucide-react'
import { Link } from 'react-router-dom'

const About = () => {
  const values = [
    {
      icon: Scale,
      title: 'Integrity',
      description: 'We uphold the highest ethical standards in all our legal practices and client relationships.'
    },
    {
      icon: Target,
      title: 'Excellence',
      description: 'We strive for excellence in every case, delivering superior legal solutions and outcomes.'
    },
    {
      icon: Users,
      title: 'Client-Focused',
      description: 'Our clients are at the center of everything we do, ensuring personalized attention and care.'
    },
    {
      icon: Heart,
      title: 'Compassion',
      description: 'We understand the human element in legal matters and approach each case with empathy.'
    }
  ]

  const timeline = [
    {
      year: '2009',
      title: 'Firm Establishment',
      description: 'Soomro Law Services was founded with a vision to provide comprehensive legal solutions.'
    },
    {
      year: '2012',
      title: 'Tax Practice Expansion',
      description: 'Expanded our services to include specialized tax law and FBR compliance services.'
    },
    {
      year: '2015',
      title: 'Corporate Law Division',
      description: 'Established dedicated corporate law division to serve business clients.'
    },
    {
      year: '2018',
      title: 'Digital Transformation',
      description: 'Implemented modern technology solutions to enhance client service delivery.'
    },
    {
      year: '2020',
      title: 'Team Expansion',
      description: 'Grew our team of legal experts to better serve our expanding client base.'
    },
    {
      year: '2024',
      title: 'Modern Practice',
      description: 'Continuing to evolve with cutting-edge legal technology and innovative solutions.'
    }
  ]

  const achievements = [
    { number: '1000+', label: 'Satisfied Clients' },
    { number: '98%', label: 'Success Rate' },
    { number: '15+', label: 'Years of Excellence' },
    { number: '50+', label: 'Corporate Clients' }
  ]

  return (
    <div className="pt-20">
      {/* Header Section */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-black py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto max-w-2xl text-center"
          >
            <div className="flex justify-center mb-8">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-4 rounded-2xl animate-glow">
                <Scale className="h-12 w-12 text-black" />
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
              About Soomro Law Services
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              <span className="gradient-text font-semibold">Just Relax! You are in Safe Hands.</span> 
              We are a modern law firm committed to providing exceptional legal services with integrity, 
              expertise, and personalized attention to every client.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="glass-card p-8"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-3 rounded-xl">
                  <Target className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white">Our Mission</h2>
              </div>
              <p className="text-gray-300 leading-relaxed">
                To provide comprehensive, high-quality legal services that protect our clients' interests 
                and achieve their objectives. We are committed to delivering personalized legal solutions 
                with integrity, professionalism, and excellence, ensuring that every client receives the 
                dedicated attention they deserve.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="glass-card p-8"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-3 rounded-xl">
                  <Eye className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white">Our Vision</h2>
              </div>
              <p className="text-gray-300 leading-relaxed">
                To be the leading law firm in Pakistan, recognized for our expertise, innovation, and 
                commitment to client success. We envision a future where legal services are accessible, 
                efficient, and delivered with the highest standards of professionalism and ethical practice.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Our Core Values
            </h2>
            <p className="text-gray-300 text-lg">
              The principles that guide everything we do
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-6 text-center group hover:scale-105 transition-all duration-300"
              >
                <div className="mx-auto w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mb-6 group-hover:animate-glow">
                  <value.icon className="h-8 w-8 text-black" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">{value.title}</h3>
                <p className="text-gray-300 text-sm leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Our Journey
            </h2>
            <p className="text-gray-300 text-lg">
              Milestones in our commitment to legal excellence
            </p>
          </motion.div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-yellow-400 to-yellow-600"></div>
            
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}
                >
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                    <div className="glass-card p-6">
                      <div className="text-yellow-400 font-bold text-xl mb-2">{item.year}</div>
                      <h3 className="text-white font-semibold text-lg mb-3">{item.title}</h3>
                      <p className="text-gray-300 text-sm leading-relaxed">{item.description}</p>
                    </div>
                  </div>
                  
                  <div className="relative z-10 w-4 h-4 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full border-4 border-black"></div>
                  
                  <div className="w-1/2"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Our Achievements
            </h2>
            <p className="text-gray-300 text-lg">
              Numbers that reflect our commitment to excellence
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <motion.div
                key={achievement.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-8 text-center group hover:scale-105 transition-all duration-300"
              >
                <div className="stat-number mb-2 group-hover:animate-glow">{achievement.number}</div>
                <p className="text-gray-300 font-medium">{achievement.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Why Choose Soomro Law Services?
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              We combine legal expertise with modern technology and personalized service
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Experienced Team',
                description: 'Our team of seasoned legal professionals brings decades of combined experience.',
                icon: '👥'
              },
              {
                title: 'Comprehensive Services',
                description: 'From civil litigation to tax compliance, we offer a full range of legal services.',
                icon: '⚖️'
              },
              {
                title: 'Client-Centric Approach',
                description: 'We prioritize our clients\' needs and provide personalized legal solutions.',
                icon: '🎯'
              },
              {
                title: 'Modern Technology',
                description: 'We leverage cutting-edge technology to enhance our legal service delivery.',
                icon: '💻'
              },
              {
                title: 'Transparent Communication',
                description: 'We maintain clear and open communication throughout the legal process.',
                icon: '📞'
              },
              {
                title: 'Proven Track Record',
                description: 'Our success rate and client satisfaction speak to our commitment to excellence.',
                icon: '🏆'
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-6 group hover:scale-105 transition-all duration-300"
              >
                <div className="text-4xl mb-4 group-hover:animate-float">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                <p className="text-gray-300 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-yellow-500/10 to-yellow-600/10">
        <div className="mx-auto max-w-4xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Ready to Work With Us?
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Let's discuss how we can help you with your legal needs.
            </p>
            <Link
              to="/consultation"
              className="btn-gold px-8 py-4 rounded-lg text-lg font-semibold inline-flex items-center"
            >
              Get Started Today
              <CheckCircle className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default About

