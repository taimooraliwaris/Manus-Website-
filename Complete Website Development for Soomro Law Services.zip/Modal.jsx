import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, CheckCircle, XCircle, Info } from 'lucide-react'
import { useModal } from '../contexts/ModalContext'

const Modal = () => {
  const { modal, hideModal } = useModal()

  const getIcon = () => {
    switch (modal.type) {
      case 'success':
        return <CheckCircle className="w-12 h-12 text-green-500" />
      case 'error':
        return <XCircle className="w-12 h-12 text-red-500" />
      case 'info':
        return <Info className="w-12 h-12 text-blue-500" />
      default:
        return <CheckCircle className="w-12 h-12 text-green-500" />
    }
  }

  const getColors = () => {
    switch (modal.type) {
      case 'success':
        return 'border-green-500/30 bg-green-500/10'
      case 'error':
        return 'border-red-500/30 bg-red-500/10'
      case 'info':
        return 'border-blue-500/30 bg-blue-500/10'
      default:
        return 'border-green-500/30 bg-green-500/10'
    }
  }

  return (
    <AnimatePresence>
      {modal.isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={hideModal}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className={`relative w-full max-w-md p-6 rounded-lg border glassmorphism ${getColors()}`}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={hideModal}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col items-center text-center space-y-4">
              <div className="flex-shrink-0">
                {getIcon()}
              </div>

              {modal.title && (
                <h3 className="text-xl font-semibold text-white">
                  {modal.title}
                </h3>
              )}

              {modal.message && (
                <p className="text-gray-300 leading-relaxed">
                  {modal.message}
                </p>
              )}

              <button
                onClick={hideModal}
                className="px-6 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors gold-glow"
              >
                OK
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default Modal

