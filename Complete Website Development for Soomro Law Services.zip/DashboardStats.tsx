'use client'

import { useEffect, useState } from 'react'
import { Users, Calendar, Star, Briefcase } from 'lucide-react'

interface Stats {
  totalConsultations: number
  totalReviews: number
  totalTeamMembers: number
  totalServices: number
}

export default function DashboardStats() {
  const [stats, setStats] = useState<Stats>({
    totalConsultations: 0,
    totalReviews: 0,
    totalTeamMembers: 0,
    totalServices: 0
  })

  useEffect(() => {
    // Mock data for now - in real implementation, fetch from API
    setStats({
      totalConsultations: 45,
      totalReviews: 28,
      totalTeamMembers: 4,
      totalServices: 10
    })
  }, [])

  const statCards = [
    {
      title: 'Total Consultations',
      value: stats.totalConsultations,
      icon: Calendar,
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Total Reviews',
      value: stats.totalReviews,
      icon: Star,
      color: 'from-gold-500 to-gold-600'
    },
    {
      title: 'Team Members',
      value: stats.totalTeamMembers,
      icon: Users,
      color: 'from-green-500 to-green-600'
    },
    {
      title: 'Services',
      value: stats.totalServices,
      icon: Briefcase,
      color: 'from-purple-500 to-purple-600'
    }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((card, index) => (
        <div
          key={index}
          className="bg-dark-800/50 backdrop-blur-sm border border-gold-500/20 rounded-2xl p-6 hover:border-gold-500/40 transition-all duration-300"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm font-medium">{card.title}</p>
              <p className="text-3xl font-bold text-white mt-2">{card.value}</p>
            </div>
            <div className={`bg-gradient-to-r ${card.color} p-3 rounded-xl`}>
              <card.icon className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

