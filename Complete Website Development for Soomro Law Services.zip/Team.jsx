import React from 'react'
import { motion } from 'framer-motion'
import { Users, Phone, Mail, MapPin, Award, Briefcase } from 'lucide-react'
import { Link } from 'react-router-dom'

const Team = () => {
  const teamData = [
    {
      name: 'Ali Soomro',
      position: 'Senior Advocate High Court',
      specialization: 'Member Lahore Tax Bar Association',
      phone: '+92 305 4622306',
      email: 'soomrolawservices@gmail.com',
      experience: '15+ Years',
      cases: '500+',
      expertise: ['Civil Law', 'Criminal Law', 'Corporate Law', 'Tax Law'],
      description: 'Senior advocate with extensive experience in high court proceedings and tax law matters.',
      image: '👨‍💼'
    },
    {
      name: 'Sadam Wako',
      position: 'Advocate High Court',
      specialization: 'Criminal Defense & Civil Litigation',
      phone: '+92 313 3448921',
      email: 'soomrolawservices@gmail.com',
      experience: '12+ Years',
      cases: '400+',
      expertise: ['Criminal Defense', 'Civil Litigation', 'Labour Law', 'Family Law'],
      description: 'Experienced advocate specializing in criminal defense and civil litigation with a strong track record.',
      image: '👨‍⚖️'
    },
    {
      name: 'Farooq Haider Soomro',
      position: 'Income Tax Practitioner',
      specialization: 'Tax Services & Compliance',
      phone: '+92 309 5407616',
      email: 'soomrolawservices@gmail.com',
      experience: '10+ Years',
      cases: '300+',
      expertise: ['Income Tax', 'Sales Tax', 'FBR Compliance', 'Tax Planning'],
      description: 'Specialized tax practitioner with deep expertise in income tax and FBR compliance matters.',
      image: '📊'
    },
    {
      name: 'Hafsa Haider',
      position: 'Manager Audit & Accounts',
      specialization: 'Financial Auditing & Accounting',
      phone: '+92 314 4622396',
      email: 'soomrolawservices@gmail.com',
      experience: '8+ Years',
      cases: '200+',
      expertise: ['Financial Audits', 'Accounting', 'Financial Statements', 'Compliance'],
      description: 'Expert in financial auditing and accounting with comprehensive knowledge of financial compliance.',
      image: '📈'
    }
  ]

  return (
    <div className="pt-20">
      {/* Header Section */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-black py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto max-w-2xl text-center"
          >
            <div className="flex justify-center mb-8">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-4 rounded-2xl animate-glow">
                <Users className="h-12 w-12 text-black" />
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
              Our Expert Legal Team
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-300">
              Meet our experienced legal professionals who are dedicated to providing 
              exceptional legal services with integrity, expertise, and personalized attention.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Team Grid */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {teamData.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-card p-8 group hover:scale-105 transition-all duration-300"
              >
                {/* Profile Header */}
                <div className="flex items-start space-x-6 mb-6">
                  <div className="w-24 h-24 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-4xl group-hover:animate-glow transition-all duration-300">
                    {member.image}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-white mb-2">{member.name}</h3>
                    <p className="text-yellow-400 font-semibold mb-1">{member.position}</p>
                    <p className="text-gray-300 text-sm">{member.specialization}</p>
                  </div>
                </div>

                {/* Description */}
                <p className="text-gray-300 mb-6 leading-relaxed">{member.description}</p>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-black/30 rounded-lg p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      <Award className="h-5 w-5 text-yellow-400 mr-2" />
                      <span className="text-yellow-400 font-bold">{member.experience}</span>
                    </div>
                    <p className="text-gray-300 text-sm">Experience</p>
                  </div>
                  <div className="bg-black/30 rounded-lg p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      <Briefcase className="h-5 w-5 text-yellow-400 mr-2" />
                      <span className="text-yellow-400 font-bold">{member.cases}</span>
                    </div>
                    <p className="text-gray-300 text-sm">Cases Handled</p>
                  </div>
                </div>

                {/* Expertise */}
                <div className="mb-6">
                  <h4 className="text-white font-semibold mb-3">Areas of Expertise:</h4>
                  <div className="flex flex-wrap gap-2">
                    {member.expertise.map((skill, skillIndex) => (
                      <span
                        key={skillIndex}
                        className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-sm border border-yellow-500/30"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Contact Info */}
                <div className="space-y-3 pt-6 border-t border-gray-700">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-4 w-4 text-yellow-400 flex-shrink-0" />
                    <span className="text-gray-300 text-sm">{member.phone}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-4 w-4 text-yellow-400 flex-shrink-0" />
                    <span className="text-gray-300 text-sm">{member.email}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Office Location */}
      <section className="py-24 bg-black/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
              Visit Our Office
            </h2>
            <p className="text-gray-300 text-lg">
              We're conveniently located to serve our clients across the region
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Office Info */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="glass-card p-8"
            >
              <h3 className="text-2xl font-bold text-white mb-6">Office Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                    <MapPin className="h-6 w-6 text-black" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Address</h4>
                    <p className="text-gray-300">Soomro Law Services</p>
                    <p className="text-gray-300">Fateh Garh, LHR</p>
                    <p className="text-gray-300">Pakistan</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                    <Phone className="h-6 w-6 text-black" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Contact Numbers</h4>
                    <div className="space-y-1 text-gray-300">
                      <p>+92 314 4622396</p>
                      <p>+92 305 4622396</p>
                      <p>+92 313 3448921</p>
                      <p>+92 309 5407616</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-3 rounded-lg">
                    <Mail className="h-6 w-6 text-black" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Email</h4>
                    <p className="text-gray-300">soomrolawservices@gmail.com</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Office Hours */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="glass-card p-8"
            >
              <h3 className="text-2xl font-bold text-white mb-6">Office Hours</h3>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-gray-700">
                  <span className="text-gray-300">Monday - Friday</span>
                  <span className="text-yellow-400 font-semibold">9:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-700">
                  <span className="text-gray-300">Saturday</span>
                  <span className="text-yellow-400 font-semibold">10:00 AM - 2:00 PM</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="text-gray-300">Sunday</span>
                  <span className="text-red-400 font-semibold">Closed</span>
                </div>
              </div>

              <div className="mt-8 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                <p className="text-yellow-400 text-sm">
                  <strong>Note:</strong> Emergency consultations available by appointment. 
                  Please call ahead to schedule your visit.
                </p>
              </div>

              <div className="mt-6">
                <Link
                  to="/consultation"
                  className="w-full btn-gold py-3 rounded-lg text-center font-semibold block"
                >
                  Schedule a Meeting
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Team

