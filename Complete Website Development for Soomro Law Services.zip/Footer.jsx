import React from 'react'
import { Link } from 'react-router-dom'
import { Scale, Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react'

const Footer = () => {
  const quickLinks = [
    { name: 'Home', href: '/' },
    { name: 'About Us', href: '/about' },
    { name: 'Our Services', href: '/services' },
    { name: 'Our Team', href: '/team' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/consultation' },
  ]

  const legalServices = [
    'Civil Litigation',
    'Criminal Defense',
    'Corporate Law',
    'Tax Services',
    'Company Formation',
    'Trademark Registration',
    'Financial Audits',
    'Legal Consultation',
  ]

  return (
    <footer className="bg-black/90 border-t border-yellow-500/20">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 p-2 rounded-xl">
                <Scale className="h-6 w-6 text-black" />
              </div>
              <div>
                <div className="text-lg font-bold text-white">Soomro Law Services</div>
                <div className="text-sm gradient-text">Just Relax! You are in Safe Hands</div>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Expert legal counsel with a modern approach. We provide comprehensive legal solutions 
              tailored to your specific needs with integrity and excellence.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Services */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Legal Services</h3>
            <ul className="space-y-3">
              {legalServices.map((service) => (
                <li key={service}>
                  <span className="text-gray-300 text-sm">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Contact Information</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-gray-300 text-sm">Soomro Law Services</p>
                  <p className="text-gray-300 text-sm">Fateh Garh, LHR</p>
                  <p className="text-gray-300 text-sm">Pakistan</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-yellow-400 flex-shrink-0" />
                  <span className="text-gray-300 text-sm">+92 314 4622396</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-yellow-400 flex-shrink-0" />
                  <span className="text-gray-300 text-sm">+92 305 4622396</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-yellow-400 flex-shrink-0" />
                  <span className="text-gray-300 text-sm">+92 313 3448921</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-yellow-400 flex-shrink-0" />
                  <span className="text-gray-300 text-sm">+92 309 5407616</span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-yellow-400 flex-shrink-0" />
                <span className="text-gray-300 text-sm">soomrolawservices@gmail.com</span>
              </div>

              <div className="mt-6">
                <h4 className="text-white font-medium mb-2">Office Hours</h4>
                <p className="text-gray-300 text-sm">Monday - Friday: 9:00 AM - 6:00 PM</p>
                <p className="text-gray-300 text-sm">Saturday: 10:00 AM - 2:00 PM</p>
                <p className="text-gray-300 text-sm">Sunday: Closed</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Soomro Law Services. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="/privacy" className="text-gray-400 hover:text-yellow-400 text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-gray-400 hover:text-yellow-400 text-sm transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

