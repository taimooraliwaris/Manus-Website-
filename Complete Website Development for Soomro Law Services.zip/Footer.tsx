import Link from 'next/link'
import { Scale, Mail, Phone, MapPin, Globe, Facebook, Instagram } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-dark-950 border-t border-gold-500/20">
      <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-gradient-to-r from-gold-400 to-gold-600 p-2 rounded-lg">
                <Scale className="h-8 w-8 text-dark-900" />
              </div>
              <div>
                <span className="text-xl font-bold text-white">Soomro Law Services</span>
                <p className="text-xs text-gold-400">Just Relax! You are in Safe Hands</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Professional legal services with a modern approach. We provide expert legal counsel 
              and representation across various practice areas with integrity and excellence.
            </p>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-gray-300">
                <Mail className="h-5 w-5 text-gold-400" />
                <span>soomrolawservices@gmail.com</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Phone className="h-5 w-5 text-gold-400" />
                <span>+92 314 4622396</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Globe className="h-5 w-5 text-gold-400" />
                <span>soomrolawservice.odoo.com</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <MapPin className="h-5 w-5 text-gold-400" />
                <span>Soomro Law Services, Fateh Garh, LHR</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about" className="text-gray-300 hover:text-gold-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/team" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Our Team
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/consultation" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Book Consultation
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-6">Legal Services</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/services" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Civil & Criminal Law
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Corporate Law
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Tax Services
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Business Registration
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-gold-400 transition-colors">
                  Audit & Compliance
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gold-500/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex space-x-6 mb-4 md:mb-0">
              <a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
            <p className="text-gray-400 text-sm">
              © 2024 Soomro Law Services. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}

