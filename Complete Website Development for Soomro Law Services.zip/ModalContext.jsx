import React, { createContext, useContext, useState } from 'react'

const ModalContext = createContext()

export const useModal = () => {
  const context = useContext(ModalContext)
  if (!context) {
    throw new Error('useModal must be used within a ModalProvider')
  }
  return context
}

export const ModalProvider = ({ children }) => {
  const [modal, setModal] = useState({
    isOpen: false,
    type: 'success', // 'success' | 'error' | 'info'
    title: '',
    message: '',
    onClose: null
  })

  const showModal = ({ type = 'success', title, message, onClose = null }) => {
    setModal({
      isOpen: true,
      type,
      title,
      message,
      onClose
    })
  }

  const hideModal = () => {
    if (modal.onClose) {
      modal.onClose()
    }
    setModal(prev => ({ ...prev, isOpen: false }))
  }

  const showSuccess = (title, message, onClose = null) => {
    showModal({ type: 'success', title, message, onClose })
  }

  const showError = (title, message, onClose = null) => {
    showModal({ type: 'error', title, message, onClose })
  }

  const showInfo = (title, message, onClose = null) => {
    showModal({ type: 'info', title, message, onClose })
  }

  return (
    <ModalContext.Provider value={{
      modal,
      showModal,
      hideModal,
      showSuccess,
      showError,
      showInfo
    }}>
      {children}
    </ModalContext.Provider>
  )
}

